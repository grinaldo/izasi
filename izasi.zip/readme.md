## About Izasi

Indonesia Steel Industry


## Installation

Do like default laravel installation as it's based on laravel
- setup your database: create it first
- setup the .env; including credentials and other configurations e.g database, cache, etc
- composer install
- php artisan migrate --seed

## Default Stack

Components used:
- Laravel 5.4
- Bulma css
- Mysql (version according your flavor)
- Redis (if you want to cache on it)
