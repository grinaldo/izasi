<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('_includes._head-meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_includes._head-style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_includes._head-script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <div class="overlay"></div>
        
        <div id="app"></div> 
        <?php echo $__env->make('_includes._notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>  
        <?php echo $__env->make('_includes._foot-script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('page-script'); ?>
    </body>
</html>