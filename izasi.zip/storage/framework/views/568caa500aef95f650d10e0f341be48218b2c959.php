

<?php $__env->startSection('page-title'); ?>
Izasi | Indonesia Zinc-Alumunium Steel Industries
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="home_logo__container">
    <a href="/">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="izasi-logo" class="home_logo__image">
    </a>
</div>

<div class="home-lang-placeholder">
    <a href="?lang=id"><img width="20" src="<?php echo e(asset('images/flag-id.png')); ?>" alt=""></a>
    <a href="?lang=en"><img width="20" src="<?php echo e(asset('images/flag-en.png')); ?>" alt=""></a>
</div>

<section class="home_hero__slider" style="height: 100vh !important; width:100vw !important;">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="background:url('<?php echo e(asset($banner->image)); ?>') no-repeat center; height: 100vh !important; width:100% !important; background-size:cover !important; position: relative;">
        <div class="home_hero__slider-overlay"></div>
        <div class="home_hero__slider-text">
            <?php if(\Session::get('locale') == 'en_US'): ?>
            <h2 class ="home_hero__slider-heading">
                <?php echo e($banner->name); ?>

            </h2>
            <p class="home_hero__slider-description">
                <?php echo $banner->description; ?>

            </p>
            <?php else: ?>
            <h2 class ="home_hero__slider-heading">
                <?php echo e($banner->name_ina); ?>

            </h2>
            <p class="home_hero__slider-description">
                <?php echo $banner->description_ina; ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<section class="home_menu">
    <ul>
        <?php if(\Session::get('locale') == 'en_US'): ?>
        <li><a href="<?php echo e(route('about')); ?>">ABOUT US</a></li>
        <li><a href="<?php echo e(route('articles.index')); ?>">NEWS & EVENT</a></li>
        <li><a href="<?php echo e(route('members.index')); ?>">MEMBERS</a></li>
        <li><a href="<?php echo e(route('contacts.index')); ?>">CONTACT</a></li>
        <?php else: ?>
        <li><a href="<?php echo e(route('about')); ?>">TENTANG KAMI</a></li>
        <li><a href="<?php echo e(route('articles.index')); ?>">BERITA</a></li>
        <li><a href="<?php echo e(route('members.index')); ?>">KEANGGOTAAN</a></li>
        <li><a href="<?php echo e(route('contacts.index')); ?>">KONTAK</a></li>
        <?php endif; ?>
    </ul>
</section>
<section class="home_footer" style="position: fixed; color: white; z-index: 9999;">
    <small>
        Copyright © 2018 Izasi all rights reserved
    </small>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>