<footer class="site-footer">
    <div class="company-contacts">
        <ul>
            <li><img src="<?php echo e(asset('images/icon-mail.png')); ?>" alt=""><?php echo e($companyEmail->short_description); ?></li>
            <li><img src="<?php echo e(asset('images/icon-phone.png')); ?>" alt=""><?php echo e($companyPhone->short_description); ?></li>
            <li><img src="<?php echo e(asset('images/icon-fax.png')); ?>" alt=""><?php echo e($companyFax->short_description); ?></li>
        </ul>
    </div>
    <div class="address">
        <?php echo $companyAddress->description; ?>

    </div>
    <div class="footer_socmed-container">
        <ul>
            <?php if(count($socialMedia) && !empty($socialMedia)): ?>
            <?php $__currentLoopData = $socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url($sm->url)); ?>"><img src="<?php echo e(asset(!empty($sm->image)?$sm->image:'images/icon-fb')); ?>" alt=""></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
    <div>
        <small>
            Copyright © 2018 Izasi all rights reserved
        </small>
    </div>
</footer>