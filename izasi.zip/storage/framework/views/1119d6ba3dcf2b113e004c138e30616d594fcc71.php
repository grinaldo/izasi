

<?php $__env->startSection('page-title'); ?>
<?php if(\Session::get('locale') == 'en_US'): ?>
Izasi | About Us
<?php else: ?>
Izasi | Tentang Kami
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="small-hero-rellax">
    <div class="general-overlay"></div>
    <img src="<?php echo e(asset('images/header-about.jpg')); ?>" alt="" data-rellax-speed="2">
    <?php if(\Session::get('locale') == 'en_US'): ?>
    <h2 class="rellax-title-dedicate" data-rellax-speed="-10">ABOUT IZASI</h2>
    <?php else: ?>
    <h2 class="rellax-title-dedicate" data-rellax-speed="-10">TENTANG IZASI</h2>
    <?php endif; ?>
</section>
<section class="section">
    <div class="container">
        <div class="columns">
            <div class="column is-two-thirds">
                <?php if(\Session::get('locale') == 'en_US' && !empty($milestoneImage)): ?>
                <img src="<?php echo e(asset($milestoneImage->image)); ?>" alt="milestone-image" width="100%">
                <?php elseif(\Session::get('locale') == 'id_ID' && !empty($milestoneImage->image_ina)): ?>
                <img src="<?php echo e(asset($milestoneImage->image_ina)); ?>" alt="milestone-image" width="100%">
                <?php endif; ?>
            </div>
            <div class="column is-one-thirds">
                <ul class="about-company__container">
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($company->image)): ?>
                    <li>
                        <?php if($key == 0): ?>
                        <div class="circle circle--blue"></div>
                        <?php elseif($key == 1): ?>
                        <div class="circle circle--green"></div>
                        <?php else: ?>
                        <div class="circle circle--yellow"></div>
                        <?php endif; ?>
                        <img src="<?php echo e(asset($company->image)); ?>" alt="<?php echo e($company->name); ?>">
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="section">
    <div class="container container--mid-container">
        <div class="row">
            <div class="col s12 m12">
                <?php if(!empty($about->description) && \Session::get('locale') == 'en_US'): ?>
                <p class="justified"><?php echo $about->description; ?></p>
                <?php elseif(!empty($about->description_ina) && \Session::get('locale') == 'id_ID'): ?>
                <p class="justified"><?php echo $about->description_ina; ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<div class="mobile-hide">
    <section class="small-hero" style="background:url('<?php echo e(asset('images/banner-2.jpg')); ?>') no-repeat center;">
        <div class="general-overlay"></div>
        <h2>PILLARS OF IZASI</h2>
    </section>
    <section class="section bg-light-grey">
        <div class="columns blocky">
            <?php if(!empty($strategicImage->image_ina) && \Session::get('locale') == 'id_ID'): ?>
            <img class="centerized" src="<?php echo e(asset($strategicImage->image_ina)); ?>" alt="">
            <?php else: ?>
            <img class="centerized" src="<?php echo e(asset($strategicImage->image)); ?>" alt="">
            <?php endif; ?>
        </div>
    </section>
</div>

<div class="strategic-mobile">
    <div class="columns strategic-desc">
        <section class="small-hero" style="background:url('<?php echo e(asset('images/house-top.png')); ?>') no-repeat center; background-size: 36em 12em !important;">
            <div class="general-overlay"></div>
            <?php if(\Session::get('locale') == 'en_US'): ?>
            <h2>OUR VISION</h2>
            <?php else: ?>
            <h2>VISI KAMI</h2>
            <?php endif; ?>
        </section>
    </div>
    <div class="section">
        <div class="container">
            <?php $__currentLoopData = $visions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Session::get('locale') == 'en_US'): ?>
            <p><?php echo $vision->description; ?></p>
            <?php else: ?>
            <p><?php echo $vision->description_ina; ?></p>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <section class="small-hero" style="background:url('<?php echo e(asset('images/house-bot.png')); ?>') no-repeat center; background-size: 36em 12em !important;">
        <div class="general-overlay"></div>
        <?php if(\Session::get('locale') == 'en_US'): ?>
        <h2>OUR INITIATIVES</h2>
        <?php else: ?>
        <h2>INISIATIF KAMI</h2>
        <?php endif; ?>
    </section>
    <div class="section">
        <div class="container">
            <ul class="initiatives-list">
                <?php $__currentLoopData = $initiatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $initiative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="centerized">
                    <img src="<?php echo e(asset(!empty($initiative->image) ? $initiative->image : 'images/about-icon-education.png')); ?>" alt="">
                    <?php if(\Session::get('locale') == 'en_US'): ?>
                    <h4><?php echo e($initiative->name); ?></h4>
                    <p><?php echo $initiative->description; ?></p>
                    <?php else: ?>
                    <h4><?php echo e($initiative->name_ina); ?></h4>
                    <p><?php echo $initiative->description_ina; ?></p>
                    <?php endif; ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <section class="small-hero" style="background:url('<?php echo e(asset('images/house-foundation.png')); ?>') no-repeat center; background-size: 36em 12em !important;">
        <div class="general-overlay"></div>
        <?php if(\Session::get('locale') == 'en_US'): ?>
        <h2>OUR STRATEGIC</h2>
        <?php else: ?>
        <h2>STRATEGI KAMI</h2>
        <?php endif; ?>
    </section>
    <div class="section">
        <div class="container">
            <ul class="">
                <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="centerized">
                    <?php if(\Session::get('locale') == 'en_US'): ?>
                    <p><?php echo $mission->description; ?></p>
                    <?php else: ?>
                    <p><?php echo $mission->description_ina; ?></p>
                    <?php endif; ?>
                    <br>
                    <div class="divider" style=""></div>
                    <br>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/rellax.min.js')); ?>"></script>
<script>
var rellax = new Rellax('.small-hero-rellax img');
var rellax = new Rellax('.rellax-title-dedicate');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>