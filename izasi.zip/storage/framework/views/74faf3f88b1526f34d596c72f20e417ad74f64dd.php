<?php if($notif_success = Session::get(NOTIF_SUCCESS)): ?>
<div class="alert-box">
    <div class="alert alert-success">
        <?php echo e($notif_success); ?>

        <span class="close" onclick="$(this).parent().fadeOut();">&times;</span> 
    </div>
</div>
<?php endif; ?>
<?php if($notif_info = Session::get(NOTIF_INFO)): ?>
<div class="alert-box">
    <div class="alert alert-info">
        <?php echo e($notif_info); ?>

        <span class="close" onclick="$(this).parent().fadeOut();">&times;</span> 
    </div>
</div>
<?php endif; ?>
<?php if($notif_warning = Session::get(NOTIF_WARNING)): ?>
<div class="alert-box">
    <div class="alert alert-warning">
        <?php echo e($notif_warning); ?>

        <span class="close" onclick="$(this).parent().fadeOut();">&times;</span> 
    </div>
</div>
<?php endif; ?>
<?php if($notif_danger = Session::get(NOTIF_DANGER)): ?>
<div class="alert-box">
    <div class="alert alert-danger">
        <?php echo e($notif_danger); ?>

        <span class="close" onclick="$(this).parent().fadeOut();">&times;</span> 
    </div>
</div>
<?php endif; ?>
