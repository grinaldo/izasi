<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('_includes._head-meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_includes._head-style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_includes._head-script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('page-style'); ?>
    </head>
    <body>
        <div class="overlay"></div>
        <?php echo $__env->make('_includes._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_includes._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <div id="app"></div> 
        <?php echo $__env->make('_includes._notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="site-content">
            <?php echo $__env->yieldContent('content'); ?>  
        </div>

        <?php echo $__env->make('_includes._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('_includes._foot-script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('page-script'); ?>
    </body>
</html>