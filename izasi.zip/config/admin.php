<?php

return [

    'login_url' => 'secret/login',

    'logout_url' => 'secret/login',

    'prefix_url' => 'backend',

    'lang' => [
        'id_ID' => 'INA',
    ],
];
