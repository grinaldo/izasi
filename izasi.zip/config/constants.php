<?php
return [
    'NOTIF_SUCCESS' => 'notif.suc',
    'NOTIF_WARNING' => 'notif.war',
    'NOTIF_DANGER' => 'notif.err',
    'NOTIF_INFO' => 'notif.inf',
];
