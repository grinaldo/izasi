<!-- footer content -->
<footer>
    <div class="pull-right">
        Izasi Admin and CMS
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->