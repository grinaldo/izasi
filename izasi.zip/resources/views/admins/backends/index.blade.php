@extends('admins._layouts.default')

@section('page-title')
<h3>Backend Dashboard</h3>
@endsection

@section('content')
<div class="row tile_count">
</div>
@stop

@section('page-script')
@endsection